using Vaiona.Entities.Common;

namespace BExIS.DQM.Entities.Data
{
    public class Example : BaseEntity
    {
        #region Attributes

        public virtual string Name { get; set; }


        #endregion


    }
}
